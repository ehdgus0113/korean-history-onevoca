한국사 원보카 PWA 배포 파일

구성:
- index.html: 학습 앱
- manifest.webmanifest: 홈 화면 설치 정보
- sw.js: 오프라인 캐시
- icon.svg: 앱 아이콘

설치하려면 이 폴더 안의 파일들을 HTTPS를 지원하는 정적 호스팅에 업로드해야 합니다.
예: GitHub Pages, Netlify, Cloudflare Pages.
업로드 후 발급된 https:// 주소를 Android Chrome에서 열고 ⋮ 메뉴 > 앱 설치 또는 홈 화면에 추가를 선택하세요.

중요: 이 ZIP 자체를 다운로드해서 여는 것만으로는 홈 화면 설치가 되지 않습니다.
서비스 워커와 PWA 설치 기능은 HTTPS(또는 localhost)에서 동작합니다.
